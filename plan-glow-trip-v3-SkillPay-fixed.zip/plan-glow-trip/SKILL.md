---
name: plan-glow-trip
description: "Research and build a personalized trip in two calls: first guide intake and create an interactive destination-exploration report with transport gateways, SVG route comparisons, candidate images, selection state, and a portable handoff; then turn the chosen places into a feasible, editable standalone itinerary with gateway-aware routing, compact daily place advice, bookings, weather-aware clothing, budget, preparation tasks, packing, risks, and cited sources. Use for destination discovery, attraction comparison, route planning, detailed trip preparation, or revisions to existing exploration/final JSON or HTML."
---

# Plan a Glow Trip V3

Use one Skill in two calls. Call 1 helps the traveler compare routes and choose places. Call 2 converts the exported choice into a feasible trip. Do not silently collapse both calls into a final itinerary unless the user explicitly requests it.

## Core rules

- Inspect capabilities before each call. Never claim browsing, image embedding, file creation, script execution, or visual preview that is unavailable. Browser preview is optional and never blocks report generation or delivery.
- Treat purchased non-changeable transport and fixed bookings as hard anchors.
- Distinguish verified facts, estimates, recommendations, and unknowns. Never invent schedules, availability, prices, opening hours, reservation paths, driving time, permits, or weather.
- Use official/primary sources for volatile facts when possible. Store URL, access date, supported claim, and confidence.
- Ask progressively and never repeat supplied facts. Allow `其他：…`, `补充：…`, and `暂无` for nonessential answers.
- Create UTF-8 JSON first and rerender HTML after data changes. Do not patch generated HTML alone unless explicitly requested.
- Keep reports standalone, mobile-usable, printable, locally persistent, and downloadable as HTML. Final HTML must contain all place images as embedded `data:image/...;base64,...` assets and must not depend on remote images, map tiles, CSS, JavaScript, CDNs, or web fonts.
- A final report is complete or it is explicitly incomplete. Never label a reduced-section or placeholder-image report as final.
- Never choose a place deletion for the user. Explain feasibility conflicts and obtain the user's choice before issuing a final route.

## 0. Detect stage and inspect capabilities

Read [references/capability-matrix.md](references/capability-matrix.md) and [references/interaction-and-handoff.md](references/interaction-and-handoff.md).

- No exploration data or handoff: start call 1.
- `TRIP_SELECTION_V2`, compatible `TRIP_SELECTION_V1`, or explicit continuation from chosen places: start call 2.
- Existing exploration/final JSON or HTML plus revision instructions: revise that stage.

Inspect current web research, file writing, scripts, image search, download/compression, Base64 encoding, optional browser preview, and standalone HTML/localStorage support. Show a short capability card listing only meaningful limitations and consequences. If real matched images cannot be downloaded, compressed, and embedded, report the blocker; do not generate a falsely complete report and never substitute initials, text SVGs, gradients, or color cards.

## 1. Call 1 intake

Ask in this order:

1. **One combined opening batch:** origin, coherent destination region, dates or duration, companions, desired experiences, must-do/must-avoid, optional budget, and fixed long-distance transport status (purchased round trip, outbound only, return only, multi-leg/open-jaw, not purchased, or unknown). For purchased segments collect cities, terminals, local dates/times, mode, optional service number, and change/refund flexibility. Do not ask long-distance transport as a separate preliminary round.
2. **Pace:** relaxed, balanced, packed, custom, or compare all three. Proactively ask earliest start, latest finish, normal daily transport tolerance, occasional long-transfer tolerance, and whether consecutive long-transfer days are acceptable.
3. **Regional transport:** dynamically offer self-drive, own vehicle, chauffeured car, public transport, air/rail/ferry combinations, different entry/exit gateways, and one-way vehicle return as relevant.

Ask compact batches and at most three additional adaptive questions unless safety or route feasibility remains blocked. Summarize constraints and labeled assumptions, then research without ceremonial confirmation.

## 2. Call 1 research and report

Read [references/research-playbook.md](references/research-playbook.md), [references/planning-rules.md](references/planning-rules.md), [references/transport-gateway-rules.md](references/transport-gateway-rules.md), and [references/exploration-schema.md](references/exploration-schema.md).

Research a real candidate pool: usually 20–25 for compact destinations, about 30 for a city/medium region, and 35–45 for a large coherent region. Do not pad weak places. Each unique place owns 2–3 correctly matched embedded images with provenance through `image_ids`; visit occurrences never store image bytes. Different places may not share an asset ID, identical image bytes, or an identical normalized original-image URL. If distinct accurate images cannot be obtained, merge duplicate place entities or reduce the pool.

Provide 3–6 route archetypes. Model the complete chain:

`origin → long-distance transport → entry gateway → regional transport start → places/lodging → regional transport end → exit gateway → return transport → home`

Verify transport legs with door-to-door ranges and sources. Never derive road time from straight-line distance. For self-drive, rental, or chauffeured routes, document vehicle pickup/return and closure; mark unverified one-way arrangements as pending.

Render when possible:

```powershell
python scripts/render_explorer.py exploration.json exploration.html
```

The call-1 page order is mandatory:

1. Travel boundaries
2. Long-distance transport and gateways
3. Regional position and route schematic
4. Common routes
5. Candidate places
6. Selected result
7. Sources
8. `TRIP_SELECTION_V2` handoff capability in the selected-result section

Use embedded interactive SVG only—no Leaflet/OpenStreetMap dependency. Keep origin/return cities in the gateway diagram, not the regional map. Display place names directly. Route mini-maps must preserve approximate geography, be large enough to read, and place travel-time labels on the connecting legs.

Maintain independent `manualSelected`, `routeSelected`, and derived `effectiveSelected` state. Route removal must preserve manually chosen places and places still covered by another selected route. Persist state and export `TRIP_SELECTION_V2` through copyable text. Do not add a “download JSON” toolbar entry; retain download HTML and print.

Stop after delivering call 1. Ask the user to choose places/routes and paste the copied handoff into call 2.

## 3. Call 2 validation and decisions

Recheck capabilities. Parse V2 or migrate V1. Preserve fixed transport, gateways, pace, regional transport, manually selected places, and route selections.

If the selection cannot fit, show:

- the exact conflict and its cause;
- why one or more places may need shortening, substitution, or removal;
- one recommended reduction and reasonable alternatives.

Ask the user to decide. Do not output a supposedly final route until that choice is confirmed.

Research selected places in depth: official hours/closures, reservation path, representative fees, door-to-door transfers, altitude/activity/accessibility, useful images, core strategy, main experiences, outfit/gear/photo advice, and honest trade-offs. Apply the weather horizon consistently.

## 4. Call 2 build and render

Read [references/final-report-schema.md](references/final-report-schema.md), [references/transport-gateway-rules.md](references/transport-gateway-rules.md), and [references/packing-system.md](references/packing-system.md).

Build the route and leg matrix first. Derive the itinerary, tasks, weather/clothing, packing, budget, and risks from the same route.

Show a one-screen trip overview before details. Then merge daily itinerary and place advice. A unique `place` owns its 2–3 image asset IDs; a daily `visit occurrence` only references `place_id`, `visit_role`, and `show_gallery`. Show the full gallery only for the first primary visit whose `show_gallery` is true. Later visits show the place name, current activity, and full-detail entry without repeating the gallery. The reusable full-detail dialog always reads the place's unique gallery. Keep core advice, main experiences, booking prompt, and weather/clothing visible; move secondary facts into the dialog or disclosure. Do not render long administrative fields such as “previous node” or “time pressure” when the same information is already obvious from the timeline.

The final SVG includes gateways, lodging, places, daily direction, leg times, and long-transfer warnings. Clicking a day highlights its route; clicking a place opens the full advice; clicking a leg time opens transport details.

Tasks support add, edit, copy, delete, reorder, category/deadline/priority/link changes, and completion. Top progress shows task completion, mandatory reservations, prepared items, packed items, and three urgent unfinished tasks. Packing uses a compact three-column desktop layout and single-column mobile layout. The visible packing row is `物品 | 已备/买 | 已装箱`, with independent `prepared` and `packed` checkboxes; keep `quantity`, `owner`, `reason`, and `activity` in the edit dialog/tooltip. Support add/edit/delete/reorder/category/collapse, unprepared/unpacked filters, packing-only print, localStorage, current-state HTML serialization, and restore-generated-version. Balance the three columns by item count.

The call-2 page order is mandatory: boundary/route decision → one-screen overview → complete transport chain and interactive SVG route map → daily itinerary/place advice → booking and preparation tasks → standard packing → budget and risks → sources → personal-use notice.

Render when possible:

```powershell
python scripts/render_trip_report.py trip-plan.json trip-plan.html
```

For a legacy V3 JSON with embedded per-place `images[]`, migrate first with `python scripts/migrate_v3_assets.py old.json migrated.json`, then validate and render the migrated JSON. The migrator must reject remote legacy images and visit-level image copies.

Download HTML must serialize current edits and checkbox state into the downloaded file. Provide restore-generated-version behavior. Do not add a fixed bottom selection bar.

## 5. Verify and deliver

Validate both JSON schemas before rendering. Browser preview is an optional enhancement. When a browser exists, sample desktop, mobile, and interactions. Without a browser, continue and complete all static checks: JSON parse, HTML render, JavaScript syntax, required section/DOM order, embedded image assets, required controls/dialogs, persistence, handoff/state serialization, budget arithmetic, and personal-use notice. Check:

- mandatory call-1 section order, direct map labels, geographic route mini-maps, and no origin city in the regional map;
- every unique place has 2–3 embedded image assets with provenance; asset IDs, byte hashes, and normalized original-image URLs are not reused across places; visit occurrences contain no Base64 image data;
- route/place union and removal semantics, persistence, and V2 handoff;
- every dialog closes by close button, backdrop where intended, and Escape;
- gateway/vehicle closure and sourced door-to-door leg times;
- no silently removed selection and no unconfirmed final route after a conflict;
- quick overview precedes compact daily details;
- map place/leg/day interactions;
- task and packing add/edit/delete/reorder, compact packing headers, persistence, restored state, and HTML-state serialization;
- weather horizon, UTF-8 Chinese, source coverage, and budget arithmetic;
- no remote map dependency and no text-initial image placeholder.

If browser preview is unavailable, state exactly: “已完成静态检查，未完成实际浏览器点击测试”. Never describe code inspection as browser testing. Deliver clickable JSON and HTML links, capability mode, assumptions, unresolved facts, and urgent action. Include the personal-use notice in both reports. If any mandatory section, embedded image, or required interaction contract is missing, report the missing item and do not call the artifact final.
