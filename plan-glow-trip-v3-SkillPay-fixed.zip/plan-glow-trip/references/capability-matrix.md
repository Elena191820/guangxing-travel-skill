# Capability matrix

Inspect capabilities at the start of both calls; do not infer them from the AI product name. Browser preview is optional.

| Capability | Full behavior | Required fallback |
|---|---|---|
| Current web research | Verify volatile travel facts from opened sources | Ask whether to continue with a labeled non-real-time version or switch tools |
| File writing | Write UTF-8 JSON and HTML | Return save-ready content and explain manual UTF-8 saving; do not label it a delivered file |
| Script execution | Validate and render deterministically | Render from the unchanged template and disclose every automated check that could not run |
| Image search | Find correctly matched place images and provenance | Use user-supplied real images or report the blocker |
| Download/compress/Base64 | Embed compressed real images in the asset dictionary | Report the blocker; remote images and text/gradient placeholders are not final-report fallbacks |
| Browser preview | Optionally sample desktop/mobile and clicks | Continue with JSON, HTML, JavaScript, DOM, asset, interaction-contract, and serialization static checks |
| localStorage/standalone JS | Persist state and serialize it into downloaded HTML | Report the blocker; do not call an interaction-incomplete artifact final |

## Modes

- **Full:** web, files, scripts, embedded images, static checks, and optional browser preview.
- **Static-verified:** all mandatory report and offline checks pass; no actual browser click test was performed.
- **Blocked:** a mandatory artifact capability, real embedded image, or required interaction contract is unavailable. Report the exact missing item and do not issue a simplified artifact as final.

## Non-negotiable rules

- Browser preview never blocks generation or delivery. If it is unavailable, say: `已完成静态检查，未完成实际浏览器点击测试`.
- Never describe code or DOM inspection as a browser click test.
- Final HTML may not load primary images, map tiles, CSS, JavaScript, or fonts from a remote URL.
- If real matched images cannot be embedded, report a blocker. Never use initials, text-only SVGs, gradients, or color blocks as image substitutes.
- Embedded SVG maps remain available without external map libraries or tiles.
- Keep the same JSON and handoff protocols in all modes.
