# Exploration schema V3

Create one UTF-8 object with `meta.schema = GLOW_TRIP_EXPLORATION_V3`. JSON is the only data source; change JSON and rerender instead of patching generated HTML.

```json
{
  "meta": {"schema":"GLOW_TRIP_EXPLORATION_V3","report_id":"explore-...","title":"...","region":"...","generated_at":"ISO-8601","research_cutoff":"YYYY-MM-DD","capability_mode":"full","capability_notes":[]},
  "intake": {"dates_or_duration":"...","origin":"...","return_city":"...","companions":"...","preferences":[],"must_do":[],"avoid":[],"budget":null,"pace":{},"fixed_transport":[]},
  "gateways": [],
  "gateway_preferences": {"inbound":[],"outbound":[],"open_jaw_acceptable":null},
  "regional_transport": {},
  "summary": {"scope_note":"...","selection_guidance":[],"assumptions":[],"warnings":[]},
  "image_assets": {},
  "map_nodes": [],
  "candidates": [],
  "route_archetypes": [],
  "sources": [],
  "personal_use_notice": "仅供个人行程规划使用；出发前复核交通、开放、票务、天气和安全信息。"
}
```

## Image asset and unique place

`candidate` is the call-1 unique place entity. Images live only in `image_assets`; the candidate stores 2–3 IDs.

```json
{
  "image_assets": {
    "IMG_M1_01": {
      "data_uri": "data:image/webp;base64,...",
      "source_url": "https://original-image-url.example/...",
      "credit": "...",
      "caption": "...",
      "checked_on": "YYYY-MM-DD"
    }
  },
  "candidates": [{"id":"M1","name":"...","image_ids":["IMG_M1_01","IMG_M1_02"]}]
}
```

Require stable ID, name, area, category, numeric coordinates when verified, recommendation group, score and explanation, 2–3 personalized fit reasons, 3–5 basics, main experiences, typical duration/stay, physical intensity, altitude/special environment, ticket and other fees, hours/open status, reservation need/path/link/lead time, weather/season note, principal caution, honest trade-off, checked date, and source IDs.

Mechanical image rules:

- Each unique candidate has 2–3 distinct `image_ids`; every ID exists.
- Every asset uses a valid Base64 `data:image` URI and keeps nonempty source URL, credit, caption, and checked date.
- An asset ID belongs to exactly one place. Decoded-byte hashes and normalized original-image URLs must also be unique across places and within one place.
- Do not use text-only SVG, initials, gradients, or color cards as place images.
- Route strips, cards, and dialogs resolve the same asset by ID. No duplicated Base64 exists outside `image_assets`.

## Gateway and map node

```json
{"id":"G1","name":"...","kind":"airport|station|port|city|lodging|regional_start|regional_end","lat":0,"lon":0,"status":"confirmed|typical|pending","source_ids":[]}
```

Keep the home origin out of `map_nodes` used for the regional map; represent it only in fixed transport/gateway flow.

## Route archetype

Each route requires origin, entry gateway, regional start, ordered candidate IDs, lodging nodes, regional end, exit gateway, home return, suggested/actual touring days, traveler/pace fit, season, daily skeleton, transport totals, longest leg/day, hotel moves, vehicle closure, budget impact, advantages/trade-offs, recommendation/discouragement reasons, and `legs` following [transport-gateway-rules.md](transport-gateway-rules.md).

## Exploration HTML contract

The renderer fixes this order and the validator rejects a changed/missing order:

1. `boundary` — travel boundaries
2. `gateways` — long-distance transport and gateways
3. `regional-map` — regional position and route schematic
4. `routes` — common routes
5. `candidates` — candidate places
6. `selection` — selected result and copyable `TRIP_SELECTION_V2`
7. `sources` — sources
8. footer personal-use notice

Provide sticky active navigation, back-to-top, copy/download-current-HTML/print toolbar, filters, full place dialog, and embedded SVG maps. No Leaflet/OpenStreetMap/CDN dependency. Clicking a map node, route image/node, or detail control opens the same place dialog. Dialogs close by button, Escape, and safe backdrop.

Maintain `manualSelected`, `routeSelected`, and derived `effectiveSelected`; persist and export `TRIP_SELECTION_V2`. Do not display a fixed bottom selection bar or a download-JSON toolbar button.

## Legacy migration

Run `python scripts/migrate_v3_assets.py old.json migrated.json`, then rerender. The migrator converts legacy embedded `images[]` entries into one `image_assets` dictionary and replaces each place array with `image_ids`. It refuses remote legacy image URLs because they cannot produce an offline-complete file.
