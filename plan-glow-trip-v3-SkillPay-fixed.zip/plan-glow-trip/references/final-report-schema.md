# Final report schema V3

Create one UTF-8 object with `meta.schema = GLOW_TRIP_FINAL_V3`. JSON is the only data source; modify it and rerender HTML.

```json
{
  "meta": {"schema":"GLOW_TRIP_FINAL_V3","report_id":"trip-...","title":"...","destination":"...","start_date":"YYYY-MM-DD","end_date":"YYYY-MM-DD","travelers":"...","generated_at":"ISO-8601","research_cutoff":"YYYY-MM-DD","capability_mode":"full","tagline":"..."},
  "handoff": {"source_protocol":"TRIP_SELECTION_V2"},
  "route_decision": {"status":"confirmed","conflicts":[],"user_confirmed_changes":[]},
  "transport_profile": {},
  "summary": {},
  "image_assets": {},
  "route_map": {"nodes":[],"legs":[]},
  "places": [],
  "days": [],
  "tasks": [],
  "packing_categories": [],
  "packing": [],
  "budget": {},
  "risks": [],
  "sources": [],
  "personal_use_notice": "仅供个人行程规划使用；出发前复核交通、开放、票务、天气和安全信息。"
}
```

Do not set `route_decision.status` to `confirmed` after removing, shortening, or substituting a user selection unless the user explicitly accepted it.

## Place and image assets

Each unique place requires 2–3 `image_ids` resolving to the `image_assets` contract in [exploration-schema.md](exploration-schema.md), plus area, fit reasons, basics, main experiences, duration, visit order, fees, opening, reservation object, weather/season, altitude, intensity, outfit, footwear, gear, photo advice, cautions, shorten/skip reasons, alternative, source IDs, and checked date.

Asset IDs, decoded-byte hashes, and normalized original-image URLs may not repeat within or across places. Image bytes appear only once in `image_assets`. Source URLs are attribution metadata, not rendered image addresses.

## Day and visit occurrence

Each day stores start/end, lodging, total transport, longest leg, visit time, pace assessment, weather/clothing, booking checks, items, fallback, and day cost. Use non-overlapping 24-hour times.

A place visit item uses:

```json
{"place_id":"M1","visit_role":"primary","show_gallery":true}
```

`visit_role` is one of `primary`, `revisit`, `meal`, `transit`, or `recovery`. The item must not contain `images`, `image_ids`, `data_uri`, Base64 data, or another image copy. At most the first primary visit may set `show_gallery: true`; later occurrences default to false and render the place name, current activity, and full-detail entry. The full-detail dialog always resolves the place's unique gallery.

## Route map

Use distinct node kinds for portal/airport/station/port/city/lodging/place. Each adjacent leg follows the transport leg contract and adds day number, direction, and long-transfer flag. Show place names directly and transport time on the line. Provide day highlighting plus clickable place and leg details.

## Task

Each task stores `id`, `category`, `task`, `when`, `deadline`, `priority`, `url`, `completed`, `editable`, `notes`, `place_id`, `source_ids`, `documents`, and `fee`. Support add, edit, copy, delete, reorder, category/deadline/priority/link changes, and completion. Top progress must show task completion, mandatory reservations, prepared items, packed items, and three urgent unfinished tasks.

## Packing

Use exactly the normalized fields below and the interaction contract in [packing-system.md](packing-system.md):

```json
{"id":"PK1","category":"","item":"","quantity":"","owner":"","reason":"","activity":"","prepared":false,"packed":false,"editable":true}
```

## Budget

Keep economical, comfortable, and generous bands with group/per-person scope, numeric categories and totals, transparent formulas, inclusions/exclusions, checked date, uncertainty, and named trade-offs. The validator recomputes each band and per-person values.

## Final HTML contract

The renderer fixes this order and the validator rejects a changed/missing order:

1. `overview` — travel boundary and route decision
2. `quick` — one-screen whole-trip overview
3. `route` — complete transport chain and interactive SVG map
4. `itinerary` — daily itinerary and place advice
5. `tasks` — booking and preparation tasks
6. `packing` — standard packing system
7. `budget` — budget and risks
8. `sources` — sources
9. footer personal-use notice

Provide localStorage, current-state HTML download, packing-only print, restore-generated-version, closeable dialogs, sticky navigation, and back-to-top. Full details open from map and itinerary. Do not use a fixed bottom selection bar. Final HTML has no remote image, map, CSS, JavaScript, CDN, or font dependency.

For legacy JSON, run `python scripts/migrate_v3_assets.py old.json migrated.json`, then rerender. The same command also renames packing aliases `qty → quantity`, `for_days/for_days_or_activity → activity`, and `name → item` when the canonical field is absent. Remote legacy images and visit-level image copies are reported as blockers instead of silently retained.
