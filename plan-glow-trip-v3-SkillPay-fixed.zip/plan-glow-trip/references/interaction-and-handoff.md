# Interaction and handoff

## Call 1 question sequence

1. Show the capability card.
2. Ask one combined opening batch: origin, destination region, dates/duration, companions, experiences, must-do/must-avoid, optional budget, and fixed long-distance transport status (purchased round trip, outbound only, return only, multi-leg/open-jaw, not purchased, or unknown). Do not create a separate preliminary round only for long-distance transport.
3. In that same response slot, collect purchased segment mode, local departure/arrival city and terminal, date/time, optional service number, and change/refund flexibility. Treat non-changeable segments as hard anchors.
4. Proactively ask pace (`轻松 / 均衡 / 紧凑 / 自定义 / 暂无并比较`), earliest start, latest finish, normal daily transport limit, occasional long-transfer limit, and consecutive-long-transfer tolerance.
5. Ask regional transport choices relevant to the destination: public transport, own car, rental, chauffeured vehicle, air/rail/ferry, different entry/exit gateways, and one-way vehicle return.
6. Ask no more than three additional questions unless a safety or feasibility blocker remains.

Summarize constraints and labeled assumptions. Ask for confirmation only for a material contradiction.

## Selection state

Maintain three independent concepts:

- `manualSelected`: places explicitly toggled by the user;
- `routeSelected`: selected route IDs;
- `effectiveSelected`: union of `manualSelected` and all candidate IDs from selected routes.

On route removal, recompute the union. Never delete a manually selected place or a place still included by another selected route. A user may manually remove a route-derived place only by first deselecting every covering route; explain this in the UI.

Persist manual and route state to localStorage. Restore safely without overwriting revised base-data layout fields.

## TRIP_SELECTION_V2

The call-1 report provides a copy action, not a JSON-download toolbar entry. Copy both human-readable context and this envelope:

```json
{
  "protocol": "TRIP_SELECTION_V2",
  "report_id": "explore-...",
  "intake": {},
  "gateway_preferences": {
    "inbound": [],
    "outbound": [],
    "open_jaw_acceptable": null
  },
  "regional_transport": {
    "modes": [],
    "pickup": null,
    "return": null,
    "one_way_return": null
  },
  "selected_route_ids": [],
  "selected_candidate_ids": [],
  "manual_selected_candidate_ids": [],
  "user_notes": ""
}
```

Include the fixed-transport segments, pace, daily time/transport tolerances, companions, preferences, and constraints inside `intake` so a new conversation can continue without chat memory.

## V1 migration

Accept `TRIP_SELECTION_V1` and migrate rather than reject:

- preserve `selected_candidate_ids`, `manual_selected_candidate_ids`, and `selected_route_ids` when present;
- map `inbound_gateway_preferences`, `outbound_gateway_preferences`, and `open_jaw_acceptable` into `gateway_preferences`;
- map `regional_transport_mode` and vehicle fields into `regional_transport`;
- preserve fixed transport and all free-text constraints;
- label newly unavailable V2 fields as unknown, not inferred.

## Call 2 conflict gate

If the selected set exceeds time or transport tolerance:

1. quantify the conflict using visit and door-to-door transport time;
2. explain why shortening/removal may be necessary;
3. propose a primary reduction plus alternatives;
4. wait for the user's decision;
5. only then issue the finalized itinerary.

Never silently remove a selected place or treat a suggested reduction as user approval.
