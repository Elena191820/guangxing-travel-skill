# Packing system

Generate packing from destination, dates, forecast/baseline, itinerary, activities, transport, luggage allowance, laundry, and companions. Do not hard-code one destination's gear globally.

Cover applicable categories: documents/tickets/money; health/medicines; safety/emergency; toiletries; skincare/cosmetics; disposable hygiene; clothing/footwear; electronics/photography; self-drive/vehicle; outdoor; destination/activity-specific; food/water; organization; shared items; departure-day items.

Add dynamic modules only when relevant: hiking/mountaineering, diving/snorkeling, skiing, island, altitude, desert, anti-theft, child, senior, or camping. Do not provide individualized medicine dosing.

Every item uses these exact fields:

```json
{
  "id": "PK1",
  "category": "",
  "item": "",
  "quantity": "",
  "owner": "",
  "reason": "",
  "activity": "",
  "prepared": false,
  "packed": false,
  "editable": true
}
```

Do not emit legacy aliases `name`, `qty`, `for_days`, or `for_days_or_activity` in new JSON.

## Interaction and layout

- Desktop: three balanced vertical columns, balanced by item count.
- Mobile: one collapsible column.
- Visible row: `物品 | 已备/买 | 已装箱`, plus compact edit/reorder/delete controls.
- Use two independent checkboxes; keep quantity, owner, reason, and activity in the edit dialog/tooltip.
- Support add/edit/delete item, category change, add/collapse category, reorder, unprepared/unpacked filters, packing-only print, restore generated version, and localStorage.
- Download current HTML serializes all edits and checkbox states without copying image Base64 outside the one asset dictionary already present in state.
- Top progress shows task completion, mandatory reservations, prepared count, packed count, and three urgent unfinished tasks.
