# Planning rules

## Candidate selection

Model fit as `traveler style × this-trip intent × hard constraints`.

Filter impossibilities first, then rank. Do not relabel a place merely to match a preference. If a requested theme has weak local supply, disclose that and use the destination's genuine strengths.

Recommendation tiers guide comparison; they do not make the decision for the user. Scores must be explained by fit and constraints, not presented as objective truth.

## Fixed transport and trip window

Put purchased transport and fixed bookings first. For every arrival/departure anchor account for:

- terminal navigation, baggage, border/security and check-in;
- terminal-to-lodging or destination transfer;
- disruption and unfamiliar-route buffer;
- early/late lodging and local transport availability.

Do not count an arrival or departure day as a full touring day unless the timing supports it. If the requested route cannot fit, name the conflict and provide a reduced plan or a clearly optional ticket-change alternative only when the user says changes are possible.

## Route feasibility

Build a matrix before scheduling:

```text
from | to | mode | door-to-door duration | frequency/last-service risk | luggage burden | source
```

Then:

- cluster geographically and avoid repeated crossings;
- include hotel-to-first-stop, inter-stop, meals, queues/security, and return time;
- add 15–30% transfer buffer, more for airports, borders, ferries, weather, altitude, children, seniors, or accessibility needs;
- use typical active windows of 6–8h relaxed, 8–10h balanced, and 10–12h packed, reduced on transfer days;
- schedule real meal/rest blocks;
- provide a primary plan and a compact weather/closure fallback.

Model home origin, entry/exit gateways, regional transport start/end, lodging, and vehicle return explicitly. Keep the home city out of the destination-region coordinate map. For every route leg use sourced door-to-door time; never convert coordinate distance into road time.

When the selected set does not fit, stop before finalization. Quantify the conflict, explain why shortening/removal may be necessary, present alternatives, and obtain the user's decision. Only user-confirmed removals or downgrades may enter the finalized route.

Flag days with more than 4h of local transfer, less than 45m major-terminal transfer margin, no rest/meal for more than 5h, or timing incompatible with the companions.

## Companion adaptation

- Children: age/height rules, toilets, food, shade, nap/early exit, and stroller reality.
- Seniors: fewer hotel changes, seating/toilets, gentler heat/altitude, and medical access.
- Solo: late return, connectivity, emergency contact, and single supplements.
- Mobility/accessibility: verify step-free routes from primary sources; never infer from photos.
- Friends/couples: allow split blocks and fairly allocate different must-dos.

State a specific risk, who it affects, and the practical alternative without fear-heavy language.

## Place advice

For each selected place provide:

- 3–5 foundational facts;
- up to 3 personalized reasons to go;
- up to 3 honest reasons to skip, shorten, or substitute;
- typical visit duration, opening information, booking need and official path;
- place-specific outfit, shoes, equipment, and optional photo palette;
- a verified image or clear fallback.

Use 2–3 correctly matched embedded images per unique place. Store each binary once in `image_assets`; the place references `image_ids`, and a visit occurrence references only `place_id`. In the final report keep core strategy, main experience, fee/reservation, and weather/clothing visible; put secondary detail in a dialog or disclosure so the daily page remains scannable.

## Outfit and packing

Derive outfits from forecast/seasonal baseline, activity, cultural rules, photo preference, laundry, and luggage allowance. Never describe a seasonal baseline as a forecast.

Deduplicate packing across days. Use the full category system in `packing-system.md`, dynamically adding only destination/activity modules that apply. The compact UI uses two booleans (`prepared`, `packed`) labeled `已备/买` and `已装箱`; retain `quantity`, `owner`, `reason`, and `activity` in editing data. Do not provide individualized medicine dosing.

## Budget

Show economical, comfortable, and generous bands. Separate group and per-person amounts. State currency, travelers, inclusions, exclusions, checked date, and uncertainty.

Use transparent formulas such as:

```text
lodging = nightly rate × rooms × nights
food = per-person daily rate × travelers × days
transport = live range or explicit excluded placeholder
activities = sum(ticket/activity × participants)
contingency = 8–15% of uncertain categories
```

If the user's ceiling is missed, show named trade-offs and approximate savings.

## Integrity checks

- Timeline arithmetic works and every stop is reachable by an allowed mode.
- Fixed bookings and terminal buffers are visible.
- Opening/closure claims match the trip date or are marked for recheck.
- Daily plan, place advice, outfits, packing, tasks, and budget describe the same trip.
- Budget categories reconcile with totals.
- High-impact assumptions appear near the relevant decision.
- Every volatile claim has a current source.
