# Research playbook

## Source priority

1. Government, tourism authority, venue, transport operator, weather service, embassy/consulate, or official booking page.
2. Reputable mapping/route service and established booking platform for representative availability or price ranges.
3. Recent specialist guide or local reporting for experience detail.
4. User-generated content only for qualitative signals such as crowd patterns, photo conditions, or recurring friction.

Open the source; never cite a search-result snippet as evidence. Prefer two independent sources for consequential claims when practical. Record conflicts and use the safer assumption.

## Research ledger

Capture usable facts as:

```text
claim | value | applies_on | source_title | publisher | url | accessed_on | confidence | notes
```

- `high`: directly supported by a relevant official source.
- `medium`: reputable secondary source or consistent cross-check.
- `low`: anecdotal, inferred, approximate, or highly volatile; never use alone as a hard constraint.

## Call-1 research

Breadth matters more than deep detail. Find a real, diverse pool and enough evidence to classify each candidate:

- official/searchable name, area, category, coordinates;
- realistic typical duration and reachability;
- one distinctive reason to consider it and one meaningful limitation;
- fit with stated preferences and companions;
- approximate cost and reservation burden;
- 2–3 correctly matched images, credit, and original source URL; prefer official tourism/venue or permissively licensed sources.

Do not exhaustively verify every candidate's live hours in call 1. Mark volatile facts for call 2 after selection.

## Call-2 research

For selected places, verify in depth:

- operating days/hours, last entry, seasonal closure, tickets and reservation path;
- public holiday/event impact;
- route frequency, last-service risk, parking or luggage burden, and door-to-door time;
- accessibility, altitude/activity load, child/senior rules, and required equipment;
- representative costs with inclusion/exclusion and checked date;
- official booking or information URL.

Recommend lodging zones before named hotels unless the user requests live inventory. Do not assert that a restaurant, hotel room, ticket, or fare is available without checking the requested date.

## Weather horizon

- 0–15 days: use a current forecast and state provider/check time and uncertainty.
- 16–30 days: give only broad trend/range with strong uncertainty; do not present precise daily weather.
- More than 30 days: do not present a forecast. Use a labeled seasonal/climate baseline for packing and outfit planning if useful.
- Unknown dates: omit weather and explain what date information is needed.

## Images

Prefer official tourism/venue images, permissively licensed sources, or clearly attributable public pages. Open the page and verify that image content matches the named place. Record credit, caption, original image URL, and access date. For both calls require 2–3 images per unique place. Download only HTTP/HTTPS resources, verify the content, compress reasonably (WebP preferred), and store each binary once in `image_assets` as `data:image/...;base64,...`. Places reference `image_ids`; visit occurrences never store images. Remote URLs are metadata only, never rendered image sources. If embedding fails, change source; if no accurate real image can be embedded, report the blocker and do not use text initials, text-only SVGs, gradients, or color cards.

## Citation rules

- Attach source IDs to the exact place, activity, cost, warning, or booking claim they support.
- Include title, publisher, URL, access date, supported claim, and confidence.
- Label modeled time/cost as an estimate and volatile facts as “出发前复核”.
- Never cite a source that was not opened.
