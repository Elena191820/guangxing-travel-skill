# Transport gateway rules

## Gateway model

Represent every route as:

`home origin → outbound long-distance leg → entry gateway → regional start → places/lodging → regional end → exit gateway → return leg → home return`

Gateways include airports, rail/bus stations, ports, self-drive entry cities, and rental pickup/return points. Keep home cities in the gateway diagram; never plot them as if geographically inside the destination-region map.

Distinguish:

1. the gateway objectively exists;
2. relevant services commonly exist;
3. a service is actually available for the user's date.

Only level 3 supports a date-specific executable connection. Otherwise say `待出票/待核验`.

## Vehicle closure

For own-car, rental, or chauffeured routes record:

- pickup/start point and time;
- return/end point and time;
- same-location or one-way return;
- whether one-way return is confirmed;
- fee/responsibility and last-mile connection to the exit gateway;
- maximum driving day and driver-rest assumptions.

An open-jaw route is executable only when both long-distance transport and regional vehicle handling close. Otherwise present it as conditional.

## Leg contract

Every adjacent route node uses:

```json
{
  "from": "node id",
  "to": "node id",
  "mode": "train/car/...",
  "distance": "approximate sourced range",
  "door_to_door": "time range",
  "pure_travel": "driving/riding time",
  "buffer": "terminal, queue, rest, luggage",
  "conditions": "road or transfer caveat",
  "pressure": "low/medium/high",
  "source_ids": ["S1"],
  "checked_on": "YYYY-MM-DD"
}
```

Do not infer road travel time from coordinate distance. Use operator schedules, official road information, or a reputable routing source, and label modeled totals as estimates.

## SVG rules

- Separate gateway and regional coordinate systems.
- Preserve approximate north/south/east/west relationships within the regional diagram.
- Show names beside nodes; do not require a numeric legend to identify places.
- Use different shapes/icons for gateways, stations, airports, lodging, cities, and places.
- Put time labels directly on route legs and make them clickable.
- Use a north arrow and `示意，不用于导航` note.
