#!/usr/bin/env python3
"""Migrate legacy embedded place images and packing aliases to the strict V3 layout."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


def clean_id(value: object) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", str(value or "PLACE")).strip("_")
    return cleaned or "PLACE"


def migrate(data: dict) -> tuple[dict, list[str]]:
    notes: list[str] = []
    schema = data.get("meta", {}).get("schema")
    if schema == "GLOW_TRIP_EXPLORATION_V3":
        places_key = "candidates"
    elif schema == "GLOW_TRIP_FINAL_V3":
        places_key = "places"
    else:
        raise ValueError("meta.schema must be GLOW_TRIP_EXPLORATION_V3 or GLOW_TRIP_FINAL_V3")
    assets = data.setdefault("image_assets", {})
    if not isinstance(assets, dict):
        raise ValueError("image_assets must be an object")
    for place in data.get(places_key, []):
        if place.get("image_ids"):
            if "images" in place:
                raise ValueError(f"place {place.get('id')} contains both image_ids and legacy images")
            continue
        legacy = place.get("images")
        if not isinstance(legacy, list) or not legacy:
            raise ValueError(f"place {place.get('id')} has no migratable legacy images")
        image_ids = []
        for index, image in enumerate(legacy, 1):
            data_uri = image.get("data_uri") or image.get("src")
            if not isinstance(data_uri, str) or not data_uri.startswith("data:image/"):
                raise ValueError(f"place {place.get('id')} image {index} is remote or not embedded; download a real image before migration")
            asset_id = f"IMG_{clean_id(place.get('id'))}_{index:02d}"
            if asset_id in assets:
                raise ValueError(f"generated asset ID already exists: {asset_id}")
            assets[asset_id] = {
                "data_uri": data_uri,
                "source_url": image.get("source_url", ""),
                "credit": image.get("credit", ""),
                "caption": image.get("caption") or place.get("name", ""),
                "checked_on": image.get("checked_on") or place.get("checked_on") or data.get("meta", {}).get("research_cutoff", ""),
            }
            image_ids.append(asset_id)
        place["image_ids"] = image_ids
        place.pop("images", None)
        place.pop("thumbnail", None)
        notes.append(f"migrated {place.get('id')} to {len(image_ids)} image assets")
    if places_key == "places":
        for item in data.get("packing", []):
            aliases = (("qty", "quantity"), ("for_days", "activity"), ("for_days_or_activity", "activity"), ("name", "item"))
            for old, new in aliases:
                if old in item and new not in item:
                    item[new] = item.pop(old)
                    notes.append(f"packing {item.get('id')} renamed {old} to {new}")
        for day in data.get("days", []):
            for item in day.get("items", []):
                if item.get("place_id") and any(key in item for key in ("images", "image_ids", "data_uri", "image_assets")):
                    raise ValueError(f"day {day.get('day')} place occurrence {item.get('place_id')} contains image data; remove it after confirming the place gallery")
    return data, notes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8-sig"))
        migrated, notes = migrate(data)
        args.output.write_text(json.dumps(migrated, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    for note in notes:
        print(f"MIGRATED: {note}")
    print(f"OK: wrote {args.output}; rerun the stage renderer to validate and render")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
