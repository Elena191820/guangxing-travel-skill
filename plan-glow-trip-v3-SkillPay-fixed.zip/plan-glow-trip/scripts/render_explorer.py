#!/usr/bin/env python3
"""Validate GLOW_TRIP_EXPLORATION_V3 JSON and render standalone offline HTML."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from validation_common import check_javascript_syntax, check_mojibake, check_offline_html, check_section_order, validate_image_assets

ROOT = ("meta", "intake", "gateways", "gateway_preferences", "regional_transport", "summary", "image_assets", "map_nodes", "candidates", "route_archetypes", "sources", "personal_use_notice")
CANDIDATE_FIELDS = ("id", "name", "area", "category", "lat", "lon", "tier", "score", "score_explanation", "fit_reasons", "basics", "main_experiences", "duration", "physical_intensity", "altitude_environment", "ticket", "opening", "reservation", "weather_note", "caution", "tradeoff", "checked_on", "source_ids", "image_ids")
ROUTE_FIELDS = ("id", "name", "origin", "entry_gateway", "regional_start", "candidate_ids", "lodging_nodes", "regional_end", "exit_gateway", "return_city", "suggested_days", "touring_days", "pace", "daily_skeleton", "total_transport", "average_daily_transport", "longest_leg", "longest_transport_day", "hotel_moves", "vehicle_closure", "budget_impact", "advantages", "tradeoffs", "recommendation_reasons", "discouragement_reasons", "legs")
LEG_FIELDS = ("from", "to", "mode", "distance", "door_to_door", "pure_travel", "buffer", "conditions", "pressure", "source_ids", "checked_on")
SECTIONS = ("boundary", "gateways", "regional-map", "routes", "candidates", "selection", "sources", "personal-use")


def validate(data: dict) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ["root must be an object"], warnings
    for key in ROOT:
        if key not in data:
            errors.append(f"missing root field: {key}")
    meta = data.get("meta", {})
    if meta.get("schema") != "GLOW_TRIP_EXPLORATION_V3":
        errors.append("meta.schema must be GLOW_TRIP_EXPLORATION_V3")
    for key in ("report_id", "title", "region", "generated_at", "research_cutoff", "capability_mode"):
        if not meta.get(key):
            errors.append(f"meta.{key} is required")
    if not str(data.get("personal_use_notice", "")).strip():
        errors.append("personal_use_notice is required")
    seen: set[str] = set()
    for index, place in enumerate(data.get("candidates", [])):
        pid = str(place.get("id", ""))
        if not pid or not place.get("name"):
            errors.append(f"candidates[{index}] requires id and name")
        if pid in seen:
            errors.append(f"duplicate candidate id: {pid}")
        seen.add(pid)
        for key in CANDIDATE_FIELDS:
            if key not in place:
                errors.append(f"candidate {pid or index} missing {key}")
        if not 2 <= len(place.get("fit_reasons", [])) <= 3:
            errors.append(f"candidate {pid} requires 2-3 fit_reasons")
        if not 3 <= len(place.get("basics", [])) <= 5:
            errors.append(f"candidate {pid} requires 3-5 basics")
        for coordinate in ("lat", "lon"):
            if place.get(coordinate) is not None and not isinstance(place[coordinate], (int, float)):
                errors.append(f"candidate {pid} {coordinate} must be numeric or null")
        if "images" in place or "thumbnail" in place:
            errors.append(f"candidate {pid} must use image_ids, not images/thumbnail")
        if not place.get("source_ids"):
            warnings.append(f"candidate {pid} has no source_ids")
    validate_image_assets(data, "candidates", errors)
    route_ids: set[str] = set()
    for index, route in enumerate(data.get("route_archetypes", [])):
        rid = str(route.get("id", ""))
        if not rid:
            errors.append(f"route_archetypes[{index}] requires id")
        if rid in route_ids:
            errors.append(f"duplicate route id: {rid}")
        route_ids.add(rid)
        for key in ROUTE_FIELDS:
            if key not in route:
                errors.append(f"route {rid or index} missing {key}")
        unknown = set(route.get("candidate_ids", [])) - seen
        if unknown:
            errors.append(f"route {rid} references unknown candidates: {sorted(unknown)}")
        for leg_index, leg in enumerate(route.get("legs", [])):
            for key in LEG_FIELDS:
                if key not in leg:
                    errors.append(f"route {rid} leg {leg_index} missing {key}")
    if len(data.get("route_archetypes", [])) < 3:
        warnings.append("fewer than 3 route archetypes")
    check_mojibake(json.dumps(data, ensure_ascii=False), "JSON", errors)
    return errors, warnings


def render(data: dict) -> str:
    shell = (Path(__file__).resolve().parent.parent / "assets" / "explorer-shell.html").read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    return shell.replace("__TITLE__", re.sub(r"[<>]", "", str(data["meta"]["title"]))).replace("__REPORT_DATA__", payload)


def validate_html(html: str, data: dict) -> list[str]:
    errors: list[str] = []
    check_mojibake(html, "HTML", errors)
    check_section_order(html, SECTIONS, errors)
    check_offline_html(html, errors)
    for marker in ("TRIP_SELECTION_V2", "manualSelected", "routeSelected", "effectiveSelected", "localStorage", "selection_state", "downloadHtml", "copyBtn", "htmlBtn", "placeDialog", "data-close"):
        if marker not in html:
            errors.append(f"HTML missing required interaction marker: {marker}")
    for asset_id, asset in data.get("image_assets", {}).items():
        if html.count(asset.get("data_uri", "")) != 1:
            errors.append(f"HTML must contain image asset {asset_id} data exactly once")
    check_javascript_syntax(html, errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    parser.add_argument("--validate-only", action="store_true", help="validate JSON and the rendered in-memory HTML")
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot read JSON: {exc}", file=sys.stderr)
        return 2
    errors, warnings = validate(data)
    html = ""
    if not errors:
        html = render(data)
        errors.extend(validate_html(html, data))
    for warning in warnings:
        print(f"WARNING: {warning}", file=sys.stderr)
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)
    if errors:
        return 2
    if args.validate_only:
        print("OK: exploration V3 JSON and static HTML checks passed; browser click testing not performed")
        return 0
    if not args.output:
        parser.error("output is required unless --validate-only is used")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding="utf-8")
    print(f"OK: wrote {args.output}; JSON/HTML/JavaScript/offline/DOM static checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
