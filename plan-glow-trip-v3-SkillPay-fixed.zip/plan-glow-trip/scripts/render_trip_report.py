#!/usr/bin/env python3
"""Validate GLOW_TRIP_FINAL_V3 JSON and render standalone offline interactive HTML."""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

from validation_common import check_javascript_syntax, check_mojibake, check_offline_html, check_section_order, contains_embedded_image, validate_image_assets

ROOT = ("meta", "handoff", "route_decision", "transport_profile", "summary", "image_assets", "route_map", "places", "days", "tasks", "packing_categories", "packing", "packing_research_notes", "weather_snapshot", "budget", "risks", "sources", "personal_use_notice")
TASK_FIELDS = ("id", "category", "task", "when", "deadline", "priority", "url", "completed", "editable", "notes", "place_id", "source_ids", "documents", "fee")
PACKING_FIELDS = ("id", "category", "item", "quantity", "owner", "reason", "activity", "prepared", "packed", "editable")
LEG_FIELDS = ("id", "from", "to", "mode", "distance", "door_to_door", "pure_travel", "buffer", "conditions", "pressure", "source_ids", "checked_on", "day", "direction", "long_transfer")
VISIT_ROLES = {"primary", "revisit", "meal", "transit", "recovery"}
SECTIONS = ("overview", "quick", "route", "itinerary", "tasks", "packing", "budget", "sources", "personal-use")
PLACE_FIELDS = ("id", "name", "image_ids", "area", "match_reasons", "basics", "main_experiences", "duration", "visit_order", "costs", "opening", "reservation", "weather_summary", "altitude_environment", "effort", "outfit", "cautions", "tradeoffs", "fallback", "source_ids", "checked_on")
DAY_FIELDS = ("day", "date", "title", "start_point", "end_point", "lodging_zone", "total_transport_time", "longest_leg", "visit_time", "pace_note", "weather_note", "outfit_summary", "booking_checks", "items", "fallback", "day_cost", "actual_time_total", "pace_assessment")


def validate_budget(budget: dict, errors: list[str]) -> None:
    categories = budget.get("categories")
    totals = budget.get("totals")
    travelers = budget.get("traveler_count")
    if not isinstance(categories, list) or not categories:
        errors.append("budget.categories must be a non-empty list")
        return
    if not isinstance(totals, dict):
        errors.append("budget.totals must be an object")
        return
    if not isinstance(travelers, (int, float)) or travelers <= 0:
        errors.append("budget.traveler_count must be a positive number")
        travelers = None
    for band in ("economical", "comfortable", "generous"):
        values = [row.get(band) for row in categories]
        if any(not isinstance(value, (int, float)) or not math.isfinite(value) for value in values):
            errors.append(f"budget category values for {band} must be finite numbers")
            continue
        expected = sum(values)
        if not isinstance(totals.get(band), (int, float)) or not math.isclose(totals[band], expected, abs_tol=0.01):
            errors.append(f"budget.totals.{band} does not reconcile; expected {expected}")
        per_key = f"per_person_{band}"
        if travelers and (not isinstance(totals.get(per_key), (int, float)) or not math.isclose(totals[per_key], expected / travelers, abs_tol=0.01)):
            errors.append(f"budget.totals.{per_key} does not reconcile")
    for key in ("scope", "currency", "inclusions", "exclusions", "checked_on", "uncertainty", "tradeoffs"):
        if key not in budget:
            errors.append(f"budget missing {key}")


def validate(data: dict) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ["root must be an object"], warnings
    for key in ROOT:
        if key not in data:
            errors.append(f"missing root field: {key}")
    meta = data.get("meta", {})
    if meta.get("schema") != "GLOW_TRIP_FINAL_V3":
        errors.append("meta.schema must be GLOW_TRIP_FINAL_V3")
    for key in ("report_id", "title", "destination", "start_date", "end_date", "travelers", "generated_at", "research_cutoff", "capability_mode", "tagline"):
        if not meta.get(key):
            errors.append(f"meta.{key} is required")
    if data.get("handoff", {}).get("source_protocol") not in {"TRIP_SELECTION_V2", "TRIP_SELECTION_V1_MIGRATED"}:
        errors.append("handoff.source_protocol must be TRIP_SELECTION_V2 or TRIP_SELECTION_V1_MIGRATED")
    decision = data.get("route_decision", {})
    if decision.get("status") not in {"confirmed", "user_confirmed"}:
        errors.append("route_decision must be user-confirmed before final rendering")
    for key in ("conflicts", "user_confirmed_changes"):
        if key not in decision:
            errors.append(f"route_decision missing {key}")
    if not str(data.get("personal_use_notice", "")).strip():
        errors.append("personal_use_notice is required")

    place_ids: set[str] = set()
    for index, place in enumerate(data.get("places", [])):
        pid = str(place.get("id", ""))
        if not pid or not place.get("name"):
            errors.append(f"places[{index}] requires id and name")
        if pid in place_ids:
            errors.append(f"duplicate place id: {pid}")
        place_ids.add(pid)
        for key in PLACE_FIELDS:
            if key not in place:
                errors.append(f"place {pid or index} missing {key}")
        if not 2 <= len(place.get("match_reasons", [])) <= 3:
            errors.append(f"place {pid} requires 2-3 match_reasons")
        if "images" in place:
            errors.append(f"place {pid} must use image_ids, not images")
        if len(place.get("basics", [])) < 3:
            warnings.append(f"place {pid} has fewer than 3 basics")
    validate_image_assets(data, "places", errors)

    seen_gallery: dict[str, bool] = {}
    prior_day = 0
    for day_index, day in enumerate(data.get("days", [])):
        for key in DAY_FIELDS:
            if key not in day:
                errors.append(f"days[{day_index}] missing {key}")
        day_number = day.get("day")
        if not isinstance(day_number, int) or day_number <= prior_day:
            errors.append(f"days[{day_index}].day must increase")
        if isinstance(day_number, int):
            prior_day = day_number
        last = "00:00"
        for item_index, item in enumerate(day.get("items", [])):
            start, end = str(item.get("start", "")), str(item.get("end", ""))
            if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", start) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", end):
                errors.append(f"day {day_number} item {item_index} needs HH:MM")
            elif start < last or end <= start:
                errors.append(f"day {day_number} item {item_index} overlaps or is invalid")
            last = end
            pid = item.get("place_id")
            if pid:
                if pid not in place_ids:
                    errors.append(f"day {day_number} item {item_index} references unknown place_id {pid}")
                if item.get("visit_role") not in VISIT_ROLES:
                    errors.append(f"day {day_number} place item {pid} has invalid visit_role")
                if not isinstance(item.get("show_gallery"), bool):
                    errors.append(f"day {day_number} place item {pid} requires boolean show_gallery")
                if any(key in item for key in ("images", "image_ids", "data_uri", "image_assets")) or contains_embedded_image(item):
                    errors.append(f"day {day_number} place item {pid} must not store image data")
                if item.get("show_gallery"):
                    if item.get("visit_role") != "primary":
                        errors.append(f"day {day_number} place item {pid} may show gallery only for a primary visit")
                    if seen_gallery.get(pid):
                        errors.append(f"place {pid} shows its gallery more than once")
                    seen_gallery[pid] = True

    route_map = data.get("route_map", {})
    node_ids = {node.get("id") for node in route_map.get("nodes", [])}
    node_kinds = {node.get("kind") for node in route_map.get("nodes", [])}
    if not node_kinds.intersection({"gateway", "airport", "station", "port", "city"}):
        errors.append("route_map must include at least one transport gateway/portal node")
    if not node_kinds.intersection({"lodging", "place_lodging"}):
        errors.append("route_map must include lodging")
    if not node_kinds.intersection({"place", "place_lodging"}):
        errors.append("route_map must include a place node")
    node_place_ids = {node.get("place_id") for node in route_map.get("nodes", []) if node.get("place_id")}
    unknown_node_places = node_place_ids - place_ids
    if unknown_node_places:
        errors.append(f"route map nodes reference unknown places: {sorted(unknown_node_places)}")
    for index, leg in enumerate(route_map.get("legs", [])):
        for key in LEG_FIELDS:
            if key not in leg:
                errors.append(f"route_map.legs[{index}] missing {key}")
        if leg.get("from") not in node_ids or leg.get("to") not in node_ids:
            errors.append(f"route_map.legs[{index}] references unknown node")

    task_ids: set[str] = set()
    for index, task in enumerate(data.get("tasks", [])):
        for key in TASK_FIELDS:
            if key not in task:
                errors.append(f"tasks[{index}] missing {key}")
        if task.get("id") in task_ids:
            errors.append(f"duplicate task id: {task.get('id')}")
        task_ids.add(task.get("id"))
        if not isinstance(task.get("completed"), bool) or not isinstance(task.get("editable"), bool):
            errors.append(f"tasks[{index}] completion/editable states must be boolean")

    category_names = {category.get("name") for category in data.get("packing_categories", [])}
    packing_ids: set[str] = set()
    for index, item in enumerate(data.get("packing", [])):
        for key in PACKING_FIELDS:
            if key not in item:
                errors.append(f"packing[{index}] missing {key}")
        for legacy in ("name", "qty", "for_days", "for_days_or_activity"):
            if legacy in item:
                errors.append(f"packing[{index}] uses legacy field {legacy}")
        if item.get("id") in packing_ids:
            errors.append(f"duplicate packing id: {item.get('id')}")
        packing_ids.add(item.get("id"))
        if item.get("category") not in category_names:
            errors.append(f"packing[{index}] uses unknown category")
        if not isinstance(item.get("prepared"), bool) or not isinstance(item.get("packed"), bool) or not isinstance(item.get("editable"), bool):
            errors.append(f"packing[{index}] prepared/packed/editable states must be boolean")

    validate_budget(data.get("budget", {}), errors)
    check_mojibake(json.dumps(data, ensure_ascii=False), "JSON", errors)
    return errors, warnings


def render(data: dict) -> str:
    shell = (Path(__file__).resolve().parent.parent / "assets" / "final-shell.html").read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    baseline = json.dumps({key: data[key] for key in ("tasks", "packing", "packing_categories")}, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    return shell.replace("__TITLE__", re.sub(r"[<>]", "", str(data["meta"]["title"]))).replace("__REPORT_JSON__", payload).replace("__BASELINE_JSON__", baseline)


def validate_html(html: str, data: dict) -> list[str]:
    errors: list[str] = []
    check_mojibake(html, "HTML", errors)
    check_section_order(html, SECTIONS, errors)
    check_offline_html(html, errors)
    for marker in ("localStorage", "downloadBtn", "JSON.stringify(current)", "resetBtn", "printPacking", "addTaskCategory", "editTask", "copyTask", "deleteTask", "moveRecord", "addPackCategory", "editPack", "deletePack", "data-collapse-pack", "data-pack-filter=\"unprepared\"", "data-pack-filter=\"unpacked\"", "detailDialog", "data-close", "image_assets"):
        if marker not in html:
            errors.append(f"HTML missing required interaction marker: {marker}")
    for asset_id, asset in data.get("image_assets", {}).items():
        if html.count(asset.get("data_uri", "")) != 1:
            errors.append(f"HTML must contain image asset {asset_id} data exactly once")
    check_javascript_syntax(html, errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    parser.add_argument("--validate-only", action="store_true", help="validate JSON and the rendered in-memory HTML")
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot read JSON: {exc}", file=sys.stderr)
        return 2
    errors, warnings = validate(data)
    html = ""
    if not errors:
        html = render(data)
        errors.extend(validate_html(html, data))
    for warning in warnings:
        print(f"WARNING: {warning}", file=sys.stderr)
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)
    if errors:
        return 2
    if args.validate_only:
        print("OK: final V3 JSON and static HTML checks passed; browser click testing not performed")
        return 0
    if not args.output:
        parser.error("output is required unless --validate-only is used")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding="utf-8")
    print(f"OK: wrote {args.output}; JSON/HTML/JavaScript/offline/DOM/budget static checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
