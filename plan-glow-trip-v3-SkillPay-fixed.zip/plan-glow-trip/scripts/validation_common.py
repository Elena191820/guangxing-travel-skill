"""Shared deterministic checks for Plan Glow Trip V3 renderers."""
from __future__ import annotations

import base64
import hashlib
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

MOJIBAKE = ("锟斤拷", "馃", "鈥", "鈺", "Ã", "Â", "�")
DATA_URI = re.compile(r"^data:image/(png|jpeg|jpg|webp|gif|avif);base64,([A-Za-z0-9+/=\r\n]+)$", re.I)


def check_mojibake(text: str, label: str, errors: list[str]) -> None:
    for token in MOJIBAKE:
        if token in text:
            errors.append(f"{label} contains typical mojibake token: {token}")


def normalize_url(value: str) -> str:
    try:
        p = urlsplit(value.strip())
    except ValueError:
        return value.strip()
    return urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path, p.query, ""))


def validate_image_assets(data: dict, places_key: str, errors: list[str]) -> None:
    assets = data.get("image_assets")
    if not isinstance(assets, dict) or not assets:
        errors.append("image_assets must be a non-empty object")
        return
    hash_owner: dict[str, str] = {}
    url_owner: dict[str, str] = {}
    asset_owner: dict[str, str] = {}
    referenced: set[str] = set()
    for index, place in enumerate(data.get(places_key, [])):
        pid = str(place.get("id", "")) or f"{places_key}[{index}]"
        ids = place.get("image_ids")
        if not isinstance(ids, list) or not 2 <= len(ids) <= 3:
            errors.append(f"place {pid} must have 2-3 image_ids")
            continue
        if len(ids) != len(set(ids)):
            errors.append(f"place {pid} repeats an image asset ID")
        for asset_id in ids:
            referenced.add(asset_id)
            if asset_id not in assets:
                errors.append(f"place {pid} references missing image asset {asset_id}")
                continue
            previous = asset_owner.setdefault(asset_id, pid)
            if previous != pid:
                errors.append(f"image asset {asset_id} is reused by places {previous} and {pid}")
    for asset_id, asset in assets.items():
        if not isinstance(asset, dict):
            errors.append(f"image asset {asset_id} must be an object")
            continue
        for field in ("data_uri", "source_url", "credit", "caption", "checked_on"):
            if not asset.get(field):
                errors.append(f"image asset {asset_id} missing {field}")
        match = DATA_URI.fullmatch(str(asset.get("data_uri", "")))
        if not match:
            errors.append(f"image asset {asset_id} must be an embedded raster data:image Base64 URI")
        else:
            try:
                raw = base64.b64decode(match.group(2), validate=True)
                if not raw:
                    raise ValueError("empty")
                mime = match.group(1).lower()
                signatures = {
                    "png": raw.startswith(b"\x89PNG\r\n\x1a\n"),
                    "jpeg": raw.startswith(b"\xff\xd8\xff"),
                    "jpg": raw.startswith(b"\xff\xd8\xff"),
                    "gif": raw.startswith((b"GIF87a", b"GIF89a")),
                    "webp": raw.startswith(b"RIFF") and raw[8:12] == b"WEBP",
                    "avif": len(raw) >= 12 and raw[4:8] == b"ftyp" and b"avif" in raw[8:32],
                }
                if not signatures.get(mime, False):
                    raise ValueError("signature does not match MIME type")
                digest = hashlib.sha256(raw).hexdigest()
                if digest in hash_owner:
                    errors.append(f"image assets {hash_owner[digest]} and {asset_id} have identical decoded bytes")
                else:
                    hash_owner[digest] = asset_id
            except Exception:
                errors.append(f"image asset {asset_id} has invalid Base64")
        source_url = str(asset.get("source_url", ""))
        if not re.match(r"^https?://", source_url, re.I):
            errors.append(f"image asset {asset_id} source_url must be HTTP(S) provenance")
        normalized = normalize_url(source_url)
        if normalized:
            if normalized in url_owner:
                errors.append(f"image assets {url_owner[normalized]} and {asset_id} repeat normalized source_url")
            else:
                url_owner[normalized] = asset_id
    unused = set(assets) - referenced
    if unused:
        errors.append(f"unreferenced image assets: {sorted(unused)}")


def contains_embedded_image(value) -> bool:
    if isinstance(value, str):
        return value.startswith("data:image/")
    if isinstance(value, list):
        return any(contains_embedded_image(x) for x in value)
    if isinstance(value, dict):
        return any(contains_embedded_image(x) for x in value.values())
    return False


def check_section_order(html: str, section_ids: tuple[str, ...], errors: list[str]) -> None:
    positions = []
    for section_id in section_ids:
        match = re.search(rf'<(?:section|footer)\b[^>]*\bid=["\']{re.escape(section_id)}["\']', html, re.I)
        if not match:
            errors.append(f"HTML missing required section/DOM id: {section_id}")
        else:
            positions.append((section_id, match.start()))
    if positions and [p for _, p in positions] != sorted(p for _, p in positions):
        errors.append("HTML required sections are out of order")


def check_offline_html(html: str, errors: list[str]) -> None:
    patterns = {
        "remote script": r"<script\b[^>]*\bsrc=[\"']https?://",
        "remote stylesheet/font": r"<link\b[^>]*\bhref=[\"']https?://",
        "remote static image": r"<img\b[^>]*\bsrc=[\"']https?://",
        "remote CSS import/url": r"(?:@import|url\()\s*[\"']?https?://",
    }
    for label, pattern in patterns.items():
        if re.search(pattern, html, re.I):
            errors.append(f"HTML contains {label} dependency")


def check_javascript_syntax(html: str, errors: list[str]) -> None:
    node = shutil.which("node")
    if not node:
        errors.append("Node.js is required for the mandatory JavaScript syntax check")
        return
    scripts = re.findall(r"<script(?![^>]*type=[\"']application/json[\"'])[^>]*>(.*?)</script>", html, re.I | re.S)
    if not scripts:
        errors.append("HTML contains no executable inline JavaScript")
        return
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as handle:
            handle.write("\n".join(scripts))
            temp_name = handle.name
        result = subprocess.run([node, "--check", temp_name], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if result.returncode:
            errors.append("JavaScript syntax failed: " + (result.stderr.strip() or result.stdout.strip()))
    finally:
        if temp_name:
            Path(temp_name).unlink(missing_ok=True)
